# app/handlers.py
import re
from datetime import datetime, timedelta
from aiogram import Bot, Router, F
from aiogram.filters.command import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from app.models import Run, Meal, Note, Sleep, User
from app.mistral import call_mistral
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import BotCommand
from aiogram.types import InputFile

NOTES_CALLBACK_PREFIX = "note_"
DELETE_CALLBACK_PREFIX = "delnote_"
BACK_CALLBACK_PREFIX = "back_notes"

router = Router()

async def classify_and_extract(text: str):
    """
    Просим Mistral классифицировать сообщение и извлечь данные в JSON.
    """
    prompt = f"""
Ты помощник, который классифицирует сообщения пользователя по одной из категорий:
- run (пробежка) — укажи distance_km (float) и calories (int)
- meal (приём пищи) — укажи text
- note (заметка) — укажи text
- sleep (сон) — укажи hours (float)

Верни JSON без лишних комментариев, строго в формате:
{{"type": "...", "data": {{...}}}}

Текст: "{text}"
"""
    raw = await call_mistral(prompt)
    if not raw:
        return None
    try:
        import json
        return json.loads(raw)
    except Exception:
        return None

@router.message(Command("help"))
async def help_handler(message: Message, session: AsyncSession):
    help_text = (
        "📝 Доступные команды:\n\n"
        "/start — Запуск бота и регистрация\n"
        "/thisweek — Показать текущую неделю пробежек\n"
        "/weekly — Показать статистику прошлой недели\n"
        "/notes — Показать список заметок\n"
        "/help — Показать это сообщение"
    )
    await message.answer(help_text)

@router.message(Command("start"))
async def start_handler(message: Message, session: AsyncSession):
    chat_id = message.chat.id
    async with session.begin():
        user = await session.execute(select(User).where(User.chat_id == chat_id))
        user = user.scalar_one_or_none()
        if not user:
            user = User(chat_id=chat_id)
            session.add(user)
    await message.answer("Привет! Пиши мне всё, что хочешь зафиксировать — я сам определю тип записи.")

@router.message(Command("thisweek"))
async def this_week_handler(message: Message, session: AsyncSession):
    monday = datetime.utcnow() - timedelta(days=datetime.utcnow().weekday())
    runs = (await session.execute(
        select(Run).where(
            and_(
                Run.created_at >= monday,
                Run.user_id == message.chat.id
            )
        )
    )).scalars().all()

    total_runs = len(runs)
    total_km = sum(r.distance_km for r in runs)
    total_cal = sum(r.calories for r in runs)

    await message.answer(f"🏃 Текущая неделя:\nПробежек: {total_runs}\nДистанция: {total_km:.2f} км\nКалорий: {total_cal}")


@router.message(Command("weekly"))
async def last_week_handler(message: Message, session: AsyncSession):
    today = datetime.utcnow()
    monday_this_week = today - timedelta(days=today.weekday())
    last_monday = monday_this_week - timedelta(days=7)
    last_sunday = monday_this_week - timedelta(seconds=1)

    runs = (await session.execute(
        select(Run).where(
            and_(
                Run.created_at >= last_monday,
                Run.created_at <= last_sunday,
                Run.user_id == message.chat.id
            )
        )
    )).scalars().all()

    total_runs = len(runs)
    total_km = sum(r.distance_km for r in runs)
    total_cal = sum(r.calories for r in runs)

    summary = f"Пробежек: {total_runs}\nДистанция: {total_km:.2f} км\nКалорий: {total_cal}"
    rec = await call_mistral(f"Еженедельная сводка:\n{summary}\nДай короткий дружеский совет по-русски (в две строчки).")
    if not rec:
        rec = "Держи темп и попробуй улучшить результат на этой неделе!"
    await message.answer(f"📊 Прошлая неделя:\n{summary}\n\nСовет:\n{rec}")

@router.message(Command("notes"))
async def notes_handler(message: Message, session: AsyncSession):
    await send_notes_list(message.chat.id, session, message=message)

async def send_notes_list(chat_id: int, session: AsyncSession, message: Message = None, bot=None):
    result = await session.execute(
        select(Note).where(Note.user_id == chat_id).order_by(Note.created_at.desc())
    )
    notes = result.scalars().all()

    if not notes:
        text = "У тебя пока нет сохранённых заметок."
        if message:
            await message.answer(text)
        elif bot:
            await bot.send_message(chat_id, text)
        return

    kb_builder = InlineKeyboardBuilder()
    for note in notes:
        short_text = (note.text[:30] + "...") if len(note.text) > 30 else note.text
        kb_builder.button(text=short_text, callback_data=f"{NOTES_CALLBACK_PREFIX}{note.id}")
    kb_builder.adjust(1)

    text = "📒 Выбери заметку:"
    if message:
        await message.answer(text, reply_markup=kb_builder.as_markup())
    elif bot:
        await bot.send_message(chat_id, text, reply_markup=kb_builder.as_markup())
    else:
        # Если нет ни message, ни bot — ничего не делаем
        return

### STATISTICS ###
import io
import matplotlib.pyplot as plt
from datetime import date, timedelta
from aiogram.types.input_file import BufferedInputFile

@router.message(Command("progress_week"))
async def progress_week_handler(message: Message, session: AsyncSession):
    await send_progress_chart(message, session, period="week")

@router.message(Command("progress_month"))
async def progress_month_handler(message: Message, session: AsyncSession):
    await send_progress_chart(message, session, period="month")

@router.message(Command("stats"))
async def stats_handler(message: Message, session: AsyncSession):
    user_id = message.chat.id
    async with session.begin():
        result = await session.execute(
            select(Run).where(Run.user_id == user_id)
        )
        runs = result.scalars().all()

    if not runs:
        await message.answer("Пока нет данных о пробежках.")
        return

    total_runs = len(runs)
    total_km = sum(r.distance_km for r in runs)
    total_cal = sum(r.calories for r in runs)
    avg_km = total_km / total_runs if total_runs else 0

    text = (
        f"📊 Статистика пробежек:\n"
        f"Всего пробежек: {total_runs}\n"
        f"Общая дистанция: {total_km:.2f} км\n"
        f"Средняя дистанция: {avg_km:.2f} км\n"
        f"Сожжённые калории: {total_cal}"
    )
    await message.answer(text)


async def send_progress_chart(message: Message, session: AsyncSession, period="week"):
    user_id = message.chat.id
    today = date.today()

    if period == "week":
        start_day = today - timedelta(days=today.weekday())  # Понедельник текущей недели
    elif period == "month":
        start_day = today.replace(day=1)
    else:
        start_day = today

    async with session.begin():
        result = await session.execute(
            select(Run).where(
                Run.user_id == user_id,
                Run.created_at >= start_day
            )
        )
        runs = result.scalars().all()

    if not runs:
        await message.answer("Нет данных за выбранный период.")
        return

    # Сбор данных по дням
    data_by_day = {}
    for r in runs:
        day = r.created_at.date()
        data_by_day[day] = data_by_day.get(day, 0) + r.distance_km

    days = sorted(data_by_day.keys())
    distances = [data_by_day[d] for d in days]

    # Построение графика
    plt.figure(figsize=(8, 4))
    plt.bar([d.strftime("%d-%b") for d in days], distances, color="skyblue")
    plt.title(f"Прогресс пробежек ({period})")
    plt.ylabel("км")
    plt.xlabel("Дата")
    plt.tight_layout()

    # Сохранение графика в память
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    plt.close()

    # Отправка графика через BufferedInputFile
    photo = BufferedInputFile(file=buf.read(), filename="progress.png")
    await message.answer_photo(photo)


@router.message(F.text & ~F.text.startswith("/"))
async def text_handler(message: Message, session: AsyncSession):
    classification = await classify_and_extract(message.text)
    if not classification:
        await message.answer("Не удалось понять сообщение 😅")
        return

    ctype = classification["type"]
    data = classification["data"]
    user_id = message.chat.id

    async with session.begin():
        if ctype == "run":
            session.add(Run(
                user_id=user_id,
                distance_km=data.get("distance_km", 0),
                calories=data.get("calories", 0)
            ))
            await message.answer(f"Записал пробежку: {data.get('distance_km')} км, {data.get('calories')} калорий.")
        elif ctype == "meal":
            session.add(Meal(
                user_id=user_id,
                meal_name=data.get("text", "")
            ))
            await message.answer(f"Записал приём пищи: {data.get('text')}")
        elif ctype == "note":
            session.add(Note(
                user_id=user_id,
                text=data.get("text", "")
            ))
            await message.answer("Записал заметку.")
        elif ctype == "sleep":
            session.add(Sleep(
                user_id=user_id,
                hours=data.get("hours", 0)
            ))
            await message.answer(f"Записал сон: {data.get('hours')} часов.")
        else:
            await message.answer("Не удалось классифицировать сообщение 😅")


@router.callback_query()
async def note_callback_handler(callback: CallbackQuery, session: AsyncSession):
    data = callback.data
    if not data:
        return

    # Открытие заметки
    if data.startswith(NOTES_CALLBACK_PREFIX):
        note_id = int(data[len(NOTES_CALLBACK_PREFIX):])
        result = await session.execute(select(Note).where(Note.id == note_id))
        note = result.scalar_one_or_none()

        if not note:
            await callback.answer("Заметка не найдена.", show_alert=True)
            return

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Удалить", callback_data=f"{DELETE_CALLBACK_PREFIX}{note.id}")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data=BACK_CALLBACK_PREFIX)]
        ])

        await callback.message.edit_text(
            f"📝 {note.text}",
            reply_markup=kb
        )
        await callback.answer()

    # Удаление заметки
    elif data.startswith(DELETE_CALLBACK_PREFIX):
        note_id = int(data[len(DELETE_CALLBACK_PREFIX):])
        result = await session.execute(select(Note).where(Note.id == note_id))
        note = result.scalar_one_or_none()

        if note:
            await session.delete(note)
            await session.commit()
            text = f"Заметка «{note.text[:20]}...» удалена."
        else:
            text = "Заметка уже удалена."

        await callback.message.edit_text(text)
        # Выводим заново список заметок
        await send_notes_list(callback.message.chat.id, session)
        await callback.answer()

    # Возврат к списку
    elif data == BACK_CALLBACK_PREFIX:
        await send_notes_list(callback.message.chat.id, session)
        await callback.answer()

async def set_bot_commands(bot: Bot):
    commands = [
        BotCommand(command="start", description="Запуск/перезапуск бота 🤖"),
        BotCommand(command="thisweek", description="Статистика на этой неделе 🌞"),
        BotCommand(command="weekly", description="Показать статистику прошлой недели ⏮️"),
        BotCommand(command="notes", description="Показать список заметок 📝"),
        BotCommand(command="help", description="Помощь 🆘"),
    ]
    await bot.set_my_commands(commands)


